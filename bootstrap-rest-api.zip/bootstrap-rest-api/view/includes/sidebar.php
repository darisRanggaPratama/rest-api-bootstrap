<div class="sidebar">
    <nav class="sidebar-nav">
        <a href="#" class="sidebar-link">
             .:Menu:.
        </a>
        <a href="../main.php" class="sidebar-link">
            <i class="fas fa-home"></i> Home
        </a>
        <a href="../logout.php" class="sidebar-link">
            <i class="fas fa-times-circle"></i> Exit
        </a>
    </nav>
</div>

<button class="toggle-btn">
    <i class="fas fa-bars fa-lg"></i>
</button>