<?php
return [
    'host' => 'localhost',
    'database' => 'avengers',
    'username' => 'rangga',
    'password' => 'rangga'
];
