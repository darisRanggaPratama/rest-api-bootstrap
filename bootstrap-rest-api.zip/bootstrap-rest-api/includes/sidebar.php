<div class="sidebar">
    <div class="sidebar-header">
        <h3>.:Menu:.</h3>
    </div>
    <ul class="list-unstyled">
        <li>
            <a href="#" class="active">
                <i class="fas fa-home"></i> Home
            </a>
        </li>
        <li>
            <a href="view">
                <i class="fas fa-table"></i> View
            </a>
        </li>
        <li>
            <a href="logout.php">
                <i class="fas fa-times-circle"></i> Exit
            </a>
        </li>
    </ul>
</div>
